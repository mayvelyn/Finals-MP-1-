import React, { useState, useEffect } from 'react';
import { View, TextInput, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const App = () => {
  const [temperature, setTemperature] = useState('');
  const [scale, setScale] = useState('F');
  const [gradientColors, setGradientColors] = useState(['#05c9f5', '#0802b0']);

  useEffect(() => {
    updateBackgroundColor(temperature);
  }, [temperature, scale]);

  const handleTemperatureChange = (text) => {
    if (!isNaN(text) || text === '') {
      setTemperature(text);
    }
  };

  const updateBackgroundColor = (text) => {
    const temp = parseFloat(text);
    if (isNaN(temp)) {
      setGradientColors(['#05c9f5', '#0802b0']);
      return;
    }

    let newColors;
    if (scale === 'F') {
      newColors = temp >= 32 ? ['#fff203', '#f57a07'] : ['#05c9f5', '#0802b0'];
    } else {
      newColors = temp >= 0 ? ['#fff203', '#f57a07'] : ['#05c9f5', '#0802b0'];
    }
    setGradientColors(newColors);
  };

  const convertTemperature = () => {
    if (isNaN(parseFloat(temperature))) return '';
    if (scale === 'F') {
      return ((parseFloat(temperature) - 32) * 5) / 9;
    } else {
      return (parseFloat(temperature) * 9) / 5 + 32;
    }
  };

  const displayTemperature = () => {
    if (temperature === '') {
      return '';
    }
    const temp = convertTemperature().toFixed(2);
    const unit = scale === 'F' ? '°C' : '°F';
    return `${temp} ${unit}`;
  };

  return (
    <LinearGradient colors={gradientColors} style={styles.container}>
      <Text style={styles.result}>{displayTemperature()}</Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          onChangeText={handleTemperatureChange}
          value={temperature}
          keyboardType="numeric"
          placeholder="Enter Temperature"
          placeholderTextColor="#000"
        />
        <Text style={styles.unitText}>{scale === 'F' ? '°F' : '°C'}</Text>
      </View>
      <TouchableOpacity style={styles.button} onPress={() => setScale(scale === 'F' ? 'C' : 'F')}>
        <Text style={styles.buttonText}>
          {scale === 'F' ? 'Convert to °C' : 'Convert to °F'}
        </Text>
      </TouchableOpacity>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '80%',
    marginBottom: 20,
    backgroundColor: '#fff',
    borderRadius: 25, 
    borderWidth: 1,
    borderColor: 'gray',
    paddingHorizontal: 15,
  },
  input: {
    flex: 1,
    height: 40,
    color: '#000',
  },
  unitText: {
    paddingHorizontal: 10,
    color: '#000',
  },
  result: {
    fontSize: 48, 
    fontWeight: 'bold',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#000', 
    padding: 15,
    borderRadius: 25,
  },
  buttonText: {
    color: '#fff', 
    fontSize: 16,
  },
});

export default App;